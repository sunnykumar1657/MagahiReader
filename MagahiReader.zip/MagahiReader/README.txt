APK banane ke steps (free, GitHub se):
1. github.com par free account banao -> New repository (naam: MagahiReader, Public).
2. "uploading an existing file" se is zip ke andar ke SAARE files/folders upload karo
   (.github folder samet) -> Commit.
3. Upar "Actions" tab kholo -> "Build APK" -> Run workflow. 3-5 minute ruko.
4. Green tick aane par us run me neeche "Artifacts" se MagahiReader-apk download karo (zip hai, khol kar app-debug.apk nikalo).
5. APK phone me kholo -> "Install unknown apps" allow karo -> Install.
