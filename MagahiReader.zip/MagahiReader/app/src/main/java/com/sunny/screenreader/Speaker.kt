package com.sunny.screenreader

import android.content.Context
import android.media.MediaPlayer
import android.speech.tts.TextToSpeech
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.concurrent.CountDownLatch
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit

class Speaker(private val ctx: Context) : TextToSpeech.OnInitListener {
    private val queue = LinkedBlockingQueue<String>()
    private val apiKey: String
    private val voiceId: String
    @Volatile private var ready = false
    @Volatile private var running = true
    @Volatile private var player: MediaPlayer? = null
    @Volatile private var latch: CountDownLatch? = null
    private var tts: TextToSpeech? = null
    private var worker: Thread? = null

    init {
        val p = ctx.getSharedPreferences("cfg", Context.MODE_PRIVATE)
        apiKey = p.getString("apiKey", "") ?: ""
        voiceId = p.getString("voiceId", "") ?: ""
        tts = TextToSpeech(ctx, this)
        worker = Thread { loop() }.also { it.start() }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.language = Locale("hi", "IN")
            val male = tts?.voices?.firstOrNull {
                it.locale.language == "hi" && it.name.contains("male", true) && !it.name.contains("female", true)
            }
            if (male != null) tts?.voice = male
            tts?.setPitch(0.85f)
            ready = true
        }
    }

    fun speak(text: String) { queue.put(text) }

    fun clear() {
        queue.clear()
        tts?.stop()
        try { player?.stop() } catch (e: Exception) { }
        latch?.countDown()
    }

    fun shutdown() {
        running = false
        clear()
        worker?.interrupt()
        tts?.shutdown()
    }

    private fun loop() {
        while (running) {
            try {
                val text = queue.poll(1, TimeUnit.SECONDS) ?: continue
                var done = false
                if (apiKey.isNotBlank() && voiceId.isNotBlank()) done = speakEleven(text)
                if (!done) speakLocal(text)
            } catch (e: InterruptedException) {
                return
            } catch (e: Exception) { }
        }
    }

    private fun speakLocal(text: String) {
        var tries = 0
        while (!ready && tries++ < 20) Thread.sleep(250)
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "u" + System.nanoTime())
        Thread.sleep(300)
        while (running && tts?.isSpeaking == true) Thread.sleep(200)
    }

    private fun speakEleven(text: String): Boolean {
        return try {
            val url = URL("https://api.elevenlabs.io/v1/text-to-speech/$voiceId?output_format=mp3_44100_128")
            val c = url.openConnection() as HttpURLConnection
            c.requestMethod = "POST"
            c.setRequestProperty("xi-api-key", apiKey)
            c.setRequestProperty("Content-Type", "application/json")
            c.doOutput = true
            val body = JSONObject().put("text", text).put("model_id", "eleven_multilingual_v2")
            c.outputStream.use { it.write(body.toString().toByteArray()) }
            if (c.responseCode != 200) return false
            val f = File(ctx.cacheDir, "s.mp3")
            c.inputStream.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
            val mp = MediaPlayer()
            player = mp
            mp.setDataSource(f.absolutePath)
            mp.prepare()
            val l = CountDownLatch(1)
            latch = l
            mp.setOnCompletionListener { l.countDown() }
            mp.start()
            l.await(90, TimeUnit.SECONDS)
            try { mp.release() } catch (e: Exception) { }
            player = null
            true
        } catch (e: Exception) {
            false
        }
    }
}
