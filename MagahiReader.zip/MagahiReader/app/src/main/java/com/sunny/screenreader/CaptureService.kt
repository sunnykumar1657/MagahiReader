package com.sunny.screenreader

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.devanagari.DevanagariTextRecognizerOptions

class CaptureService : Service() {
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var display: VirtualDisplay? = null
    private val handler = Handler(Looper.getMainLooper())
    private val recognizer = TextRecognition.getClient(DevanagariTextRecognizerOptions.Builder().build())
    private var speaker: Speaker? = null
    private var running = false
    private var busy = false
    private var lastScan = ""
    private val spoken = LinkedHashSet<String>()
    private var w = 0
    private var h = 0

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val code = intent?.getIntExtra("code", 0) ?: 0
        val data = intent?.getParcelableExtra<Intent>("data")
        if (data == null) { stopSelf(); return START_NOT_STICKY }

        startAsForeground()
        speaker = Speaker(this)

        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mpm.getMediaProjection(code, data)
        projection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopSelf() }
        }, handler)

        val dm = resources.displayMetrics
        w = dm.widthPixels
        h = dm.heightPixels
        reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        display = projection?.createVirtualDisplay(
            "reader", w, h, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader!!.surface, null, handler
        )

        running = true
        handler.postDelayed(scanRunnable, 1500)
        return START_NOT_STICKY
    }

    private fun startAsForeground() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("reader", "Reader", NotificationManager.IMPORTANCE_LOW))
        val n: Notification = Notification.Builder(this, "reader")
            .setContentTitle("Magahi Reader chal raha hai")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(1, n)
        }
    }

    private val scanRunnable = object : Runnable {
        override fun run() {
            if (!running) return
            scan()
            handler.postDelayed(this, 1500)
        }
    }

    private fun scan() {
        if (busy) return
        val image = reader?.acquireLatestImage() ?: return
        busy = true
        val bmp: Bitmap
        try {
            val plane = image.planes[0]
            val rowPadding = plane.rowStride - plane.pixelStride * w
            val full = Bitmap.createBitmap(w + rowPadding / plane.pixelStride, h, Bitmap.Config.ARGB_8888)
            full.copyPixelsFromBuffer(plane.buffer)
            bmp = Bitmap.createBitmap(full, 0, 0, w, h)
        } catch (e: Exception) {
            busy = false
            return
        } finally {
            image.close()
        }
        recognizer.process(InputImage.fromBitmap(bmp, 0))
            .addOnSuccessListener { onText(it.text); busy = false }
            .addOnFailureListener { busy = false }
    }

    private fun onText(t: String) {
        val stable = (t == lastScan)
        lastScan = t
        if (!stable) return
        val lines = t.split("\n").map { it.trim() }.filter { it.length >= 3 }
        val fresh = lines.filter { spoken.add(it) }
        while (spoken.size > 300) spoken.remove(spoken.first())
        if (fresh.isNotEmpty()) speaker?.speak(fresh.joinToString(". "))
    }

    override fun onDestroy() {
        running = false
        handler.removeCallbacksAndMessages(null)
        display?.release()
        reader?.close()
        projection?.stop()
        speaker?.shutdown()
        recognizer.close()
        super.onDestroy()
    }
}
