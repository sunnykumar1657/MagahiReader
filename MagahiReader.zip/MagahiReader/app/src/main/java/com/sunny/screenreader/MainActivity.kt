package com.sunny.screenreader

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.devanagari.DevanagariTextRecognizerOptions

class MainActivity : Activity() {
    private val REQ_CAPTURE = 100
    private val REQ_IMAGE = 200
    private var speaker: Speaker? = null
    private lateinit var key: EditText
    private lateinit var vid: EditText
    private lateinit var result: TextView

    private fun saveCfg() {
        getSharedPreferences("cfg", Context.MODE_PRIVATE).edit()
            .putString("apiKey", key.text.toString().trim())
            .putString("voiceId", vid.text.toString().trim()).apply()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("cfg", Context.MODE_PRIVATE)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 80, 40, 40)
        }
        val title = TextView(this).apply { text = "Magahi Screen Reader"; textSize = 24f }
        val info = TextView(this).apply {
            text = "LIVE START: screen capture allow karo, jo text dikhega wo padh kar sunayega.\n" +
                "SCREENSHOT PADHO: gallery se screenshot chuno, wo padh kar sunayega.\n\n" +
                "Apni awaaz ke liye (optional) ElevenLabs API key aur Voice ID daalo. Khali chhodoge to phone ki Hindi male awaaz chalegi."
            setPadding(0, 20, 0, 20)
        }
        key = EditText(this).apply { hint = "ElevenLabs API key (optional)"; setText(prefs.getString("apiKey", "")) }
        vid = EditText(this).apply { hint = "Voice ID (optional)"; setText(prefs.getString("voiceId", "")) }
        val start = Button(this).apply { text = "LIVE START" }
        val shot = Button(this).apply { text = "SCREENSHOT PADHO" }
        val stop = Button(this).apply { text = "STOP" }
        result = TextView(this).apply { text = ""; setPadding(0, 30, 0, 0) }
        val scroll = ScrollView(this).apply { addView(result) }

        start.setOnClickListener {
            saveCfg()
            if (Build.VERSION.SDK_INT >= 33) {
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
            }
            val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            startActivityForResult(mpm.createScreenCaptureIntent(), REQ_CAPTURE)
        }
        shot.setOnClickListener {
            saveCfg()
            val i = Intent(Intent.ACTION_GET_CONTENT).apply { type = "image/*" }
            startActivityForResult(i, REQ_IMAGE)
        }
        stop.setOnClickListener {
            stopService(Intent(this, CaptureService::class.java))
            speaker?.clear()
        }

        listOf(title, info, key, vid, start, shot, stop, scroll).forEach { root.addView(it) }
        setContentView(root)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data == null) return
        if (requestCode == REQ_CAPTURE) {
            val i = Intent(this, CaptureService::class.java)
                .putExtra("code", resultCode)
                .putExtra("data", data)
            startForegroundService(i)
        } else if (requestCode == REQ_IMAGE) {
            val uri = data.data ?: return
            result.text = "Padh raha hoon..."
            try {
                val img = InputImage.fromFilePath(this, uri)
                val rec = TextRecognition.getClient(DevanagariTextRecognizerOptions.Builder().build())
                rec.process(img)
                    .addOnSuccessListener { t ->
                        val lines = t.text.split("\n").map { it.trim() }.filter { it.length >= 2 }
                        if (lines.isEmpty()) {
                            result.text = "Koi text nahi mila."
                        } else {
                            result.text = lines.joinToString("\n")
                            speaker?.shutdown()
                            speaker = Speaker(this)
                            lines.chunked(5).forEach { speaker?.speak(it.joinToString(". ")) }
                        }
                    }
                    .addOnFailureListener { result.text = "Padhne me galti aayi." }
            } catch (e: Exception) {
                result.text = "Photo khul nahi payi."
            }
        }
    }

    override fun onDestroy() {
        speaker?.shutdown()
        super.onDestroy()
    }
}
